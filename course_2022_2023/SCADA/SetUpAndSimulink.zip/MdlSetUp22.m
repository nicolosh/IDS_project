clear all;
clc;

%% Parameters

s = tf('s');
g = 9.8;    % [m/s^2]
pw = 1220;  % [m/s]
ScaleFactor = 1e-4;

%% Initial conditions

Caoria.VolPercentage = 1.1;

%% Caoria model

% Power plant
Caoria.Pr = 38.1;  % [MW]
Caoria.Qr = 9;     % [m^3/s]
Caoria.Od = 380;   % [m^3/s]
Caoria.L = 930;    % [m]
Caoria.D = 1.5;    % [m]
Caoria.Hr = 551;   % [m]

% Catch basin
Caoria.Dm = 25;    % [m^3/s]
Caoria.A = 30;     % [m^3/s]
Caoria.MinLevel = 1395;    % [m]
Caoria.MaxLevel = 1458;    % [m]
Caoria.Volume = 28e6*ScaleFactor;      % [m^3]
Caoria.S = Caoria.Volume/(Caoria.MaxLevel - Caoria.MinLevel);
Caoria.InitVolume = Caoria.Volume*Caoria.VolPercentage; % [m^3]

% Turbine model
tw = (Caoria.L*Caoria.Qr/(pi*Caoria.D^2/2))/(g*Caoria.Hr);
te = Caoria.L/pw;
a = 1 + 5/4*s^2*(te/pi)^2 + 1/4*s^4*(te/pi)^4;
b = 1 + 40/9*s^2*(te/pi)^2 + 16/9*s^4*(te/pi)^4;
Caoria.G = 2*(b - tw*a*s)/(2*b + tw*a*s);

Caoria.C = 0.10027/s;



