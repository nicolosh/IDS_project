clear all;
close all;
clc;

%% Simulation parameters

Caoria.PercentageLevel = 0/100;
SSilvestro.PercentageLevel = 50/100;
Moline.PercentageLevel = 50/100;


%% Parameters

s = tf('s');
g = 9.8;    % [m/s^2] 
pw = 1220;  % [m/s]
VolumeScale = 1e-4;


%% Caoria station

% Power parameters
Caoria.Pr = 38.1;   % [MW]
Caoria.Qr = 9;      % [m^3/s]
Caoria.Od = 380;    % [m^3/s]
Caoria.Dm = 25;     % [m^3/s]
Caoria.A = 30;      % [m^3/s]

% Catch basin parameters
Caoria.MinLevel = 1395;     % [m]
Caoria.MaxLevel = 1458;     % [m]
Caoria.Volume = 28e6*VolumeScale;       % [m^3]
Caoria.S = Caoria.Volume/((Caoria.MaxLevel - Caoria.MinLevel)/0.7);
Caoria.InitHeight = (Caoria.MaxLevel - Caoria.MinLevel)*Caoria.PercentageLevel + Caoria.MinLevel;

% Penstock pipe parameters
Caoria.L = 930;     % [m]
Caoria.D = 1.5;     % [m]
Caoria.Hr = 551;    % [m]

% Transfer function
tw = Caoria.L*Caoria.Qr/(pi*Caoria.D^2/2)/(g*Caoria.Hr);
te = Caoria.L/pw;
a = 1 + 5/4 *s^2*te^2/pi^2  + 1/4 *s^4*te^4/pi^4;
b = 1 + 40/9*s^2*te^2/pi^2  + 16/9*s^4*te^4/pi^4;
Caoria.G = 2*(b - tw*a*s)/(2*b + tw*a*s);

% Turbine controller
Caoria.C = 0.1003/s;


%% San Silvestro station

% Power parameters
SSilvestro.Pr = 25.5;   % [MW]
SSilvestro.Qr = 8;      % [m^3/s]
SSilvestro.Od = 220;    % [m^3/s]
SSilvestro.Dm = 17;     % [m^3/s]
SSilvestro.A = 20;      % [m^3/s]

% Catch basin parameters
SSilvestro.MinLevel = 795;     % [m]
SSilvestro.MaxLevel = 881;     % [m]
SSilvestro.Volume = 10e6*VolumeScale;       % [m^3]
SSilvestro.S = SSilvestro.Volume/((SSilvestro.MaxLevel - SSilvestro.MinLevel)/0.7);
SSilvestro.InitHeight = (SSilvestro.MaxLevel - SSilvestro.MinLevel)*SSilvestro.PercentageLevel + SSilvestro.MinLevel;

% Penstock pipe parameters
SSilvestro.L = 525;     % [m]
SSilvestro.D = 2.25;    % [m]
SSilvestro.Hr = 306;    % [m]

% Transfer function
tw = SSilvestro.L*SSilvestro.Qr/(pi*SSilvestro.D^2/2)/(g*SSilvestro.Hr);
te = SSilvestro.L/pw;
a = 1 + 5/4 *s^2*te^2/pi^2  + 1/4 *s^4*te^4/pi^4;
b = 1 + 40/9*s^2*te^2/pi^2  + 16/9*s^4*te^4/pi^4;
SSilvestro.G = 2*(b - tw*a*s)/(2*b + tw*a*s);

% Turbine controller
SSilvestro.C = 0.3097/s;



%% Moline station

% Power parameters
Moline.Pr = 24.75;  % [MW]
Moline.Qr = 16;     % [m^3/s]
Moline.Od = 620;    % [m^3/s]
Moline.Dm = 20;     % [m^3/s]
Moline.A = 35;      % [m^3/s]

% Catch basin parameters
Moline.MinLevel = 552;     % [m]
Moline.MaxLevel = 565;     % [m]
Moline.Volume = 4.8e6*VolumeScale;       % [m^3]
Moline.S = Moline.Volume/((Moline.MaxLevel - Moline.MinLevel)/0.7);
Moline.InitHeight = (Moline.MaxLevel - Moline.MinLevel)*Moline.PercentageLevel + Moline.MinLevel;

% Penstock pipe parameters
Moline.L = 365;     % [m]
Moline.D = 2.3;     % [m]
Moline.Hr = 142.3;  % [m]

% Transfer function
tw = Moline.L*Moline.Qr/(pi*Moline.D^2/2)/(g*Moline.Hr);
te = Moline.L/pw;
a = 1 + 5/4 *s^2*te^2/pi^2  + 1/4 *s^4*te^4/pi^4;
b = 1 + 40/9*s^2*te^2/pi^2  + 16/9*s^4*te^4/pi^4;
Moline.G = 2*(b - tw*a*s)/(2*b + tw*a*s);

% Turbine controller
Moline.C = 0.38414/s;














