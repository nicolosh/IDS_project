clear all;
clc;

% Measurand
q = 10;

% Sensor model
a0 = 1;
a1 = 3;
a2 = 0;

% Measurement
Z = a0 + a1*q + a2*q^2;

% Actual measurements
nm = 1e2;
Bias = -3;
Zm = Z + randn(nm,1) + Bias;

Bias_est = mean(Zm - Z)
Bias

Zm2 = Zm - Bias_est

figure(1), clf, hold on;
plot(q*ones(1,length(Z)), Z, 'b+', 'MarkerSize', 20);
plot(q*ones(1,length(Zm)), Zm, 'rs')