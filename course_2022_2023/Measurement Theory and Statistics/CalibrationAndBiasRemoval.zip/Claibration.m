clear all;
clc;

%% Actual sensor model

na = randi(10,1);
A = rand(na,1);

%% Measurand

m = 1e2;
MaxValue = 20;
q = (rand(m,1)-0.5)*MaxValue;

%% Measurement results

Za = zeros(length(q),1);
for i=1:length(q)
    Za(i) = A(1);
    for j=2:length(A)
        Za(i) = Za(i) + A(j)*q(i)^(j-1);
    end
end

Z = Za + randn(length(Za),1)*1e-2;

%% Calibrate the sensor

RMSE_Th = 1e-1;

n_max = m - 1;
for n = 1:n_max
    A_est = zeros(n+1,1);
    
    % Calibration matrix
    U = ones(m, n+1);
    for i=1:m
        for j=2:n+1
            U(i,j) = q(i)^(j-1);
        end
    end
    A_est = inv(U'*U)*U'*Z;
    
    % Generate the measurements
    EstimatedSensorValue = zeros(1,length(q));
    for i=1:length(q)
        EstimatedSensorValue(i) = A_est(1);
        for j=2:length(A_est)
            EstimatedSensorValue(i) = EstimatedSensorValue(i) + A_est(j)*q(i)^(j-1);
        end
    end
    
    % Measurement error
    MError = Z - EstimatedSensorValue';
    
    % RMSE
    RMSE = sqrt(sum(MError.^2)/length(MError));
    
    % Check
    if RMSE <= RMSE_Th
        break;
    end
    
end


%% Results

disp('Actual parameters');
A'
disp('Estimated parameters');
A_est'

figure(1), clf, hold on;
x = -MaxValue:MaxValue;
nV = length(x);
ActualSensorValue = zeros(1,nV);
for i=1:nV
    ActualSensorValue(i) = A(1);
    for j=2:length(A)
        ActualSensorValue(i) = ActualSensorValue(i) + A(j)*x(i)^(j-1);
    end
end
EstimatedSensorValue = zeros(1,nV);
for i=1:nV
    EstimatedSensorValue(i) = A_est(1);
    for j=2:length(A_est)
        EstimatedSensorValue(i) = EstimatedSensorValue(i) + A_est(j)*x(i)^(j-1);
    end
end
plot(x, ActualSensorValue, 'b');
plot(x, EstimatedSensorValue, 'r--');
legend('Actual', 'Estiamted', 'Location', 'best');


    
    
    